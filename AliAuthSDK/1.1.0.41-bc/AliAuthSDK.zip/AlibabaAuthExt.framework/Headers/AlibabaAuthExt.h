//
//  AlibabaAuthExt.h
//  AlibabaAuthSDK
//
//  Created by Bangzhe Liu on 9/9/16.
//  Copyright © 2016 alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AlibabaAuthExt : NSObject

@end
